$(function() {  

    jQuery.scrollSpeed(100, 700);

});